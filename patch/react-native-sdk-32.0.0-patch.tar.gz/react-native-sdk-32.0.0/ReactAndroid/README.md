# Building React Native for Android

See the [docs on the website](https://facebook.github.io/react-native/docs/building-from-source.html#android).

# Running tests

When you submit a pull request CircleCI will automatically run all tests. To run tests locally, see [Testing](https://facebook.github.io/react-native/docs/testing.html).
